# 令和8年熊本地震 情報まとめ — 巡回と運用

Web検索は使いません。**発信元の一次情報サイトを直接巡回**して、更新をページに反映します。

## ファイル

| ファイル | 役割 |
|---|---|
| `kumamoto-support.html` | サイト本体。単一ファイルで完結 |
| `crawl.py` | 巡回クローラー。標準ライブラリのみ、依存パッケージなし |
| `state.json` | ETag / Last-Modified / 前回取得分のキャッシュ（自動生成） |
| `out/data.json` | 巡回結果（自動生成） |

## 使い方

```bash
python3 crawl.py                                # 巡回して out/data.json を更新
python3 crawl.py --inject kumamoto-support.html # HTMLに埋め込んで単一ファイルのまま最新化
python3 crawl.py -v                             # 各ソースの取得状況を表示
```

**最初にやること**: `crawl.py` の先頭の `CONTACT` を自分の連絡先に書き換えてください。相手のサーバー管理者が問題に気づいたとき、連絡する先がないと問答無用で遮断されます。

## 巡回対象（16件・すべて発信元の一次情報）

**地震**
- 気象庁 地震情報 `bosai/quake/data/list.json`
- 気象庁 防災情報XML（地震火山・高頻度）`developer/xml/feed/eqvol.xml`

**自治体**
- 熊本県 緊急・重要なお知らせ／新着情報（RSS）
- 熊本市・八代市・宇土市・氷川町・益城町（RSS）
- 氷川町 緊急情報・益城町 緊急情報（HTML）
- 美里町（新着JSON）
- 宇城市 緊急情報（HTML）

**国・報道**
- 総務省消防庁 災害情報（RSS）
- 内閣府 防災情報のページ 新着（RSS）
- NHKニュース 社会（RSS・キーワード絞り込み）

## 定期実行

### A. cron（サーバーがある場合）

```cron
*/10 * * * * cd /srv/kumamoto && /usr/bin/python3 crawl.py --inject kumamoto-support.html >> crawl.log 2>&1
```

### B. systemd timer

`/etc/systemd/system/kumamoto-crawl.service`
```ini
[Unit]
Description=Kumamoto quake info crawler
After=network-online.target

[Service]
Type=oneshot
WorkingDirectory=/srv/kumamoto
ExecStart=/usr/bin/python3 crawl.py --inject kumamoto-support.html
User=www-data
```

`/etc/systemd/system/kumamoto-crawl.timer`
```ini
[Unit]
Description=Run Kumamoto crawler every 10 minutes

[Timer]
OnBootSec=2min
OnUnitActiveSec=10min
AccuracySec=30s

[Install]
WantedBy=timers.target
```

```bash
sudo systemctl enable --now kumamoto-crawl.timer
```

### C. GitHub Actions（サーバーがない場合の推奨）

`.github/workflows/crawl.yml` を同梱しています。リポジトリに push して Settings → Pages で「GitHub Actions」を選ぶだけで、10分おきに巡回して自動デプロイされます。無料枠で足ります。

> 注意: GitHub Actions のスケジュール実行は混雑時に数分〜十数分遅れます。分単位の速報性が必要なら A か B を使ってください。

## 設計上、外せないところ

**条件付きGETは必須です。** ETag / Last-Modified を保存して `If-None-Match` / `If-Modified-Since` を送り、304 が返ったら本文を取りません。気象庁は 1日10GB を超えるダウンロードを検知するとIPを遮断します。実測で全ソースが 304 を返すことを確認済みです。

**リクエスト間隔は3秒。** robots.txt に Crawl-delay の指定はどのサイトにもありませんでしたが、災害対応で負荷が上がっている相手のサーバーに追い打ちをかけないための自主規制です。宇城市は WAF 配下なので特に注意。

**1つ落ちても止まりません。** 取得に失敗したソースは前回のキャッシュを表示し、画面上に「取得できませんでした」と明示します。黙って古い情報を出すのが一番危険です。

**取得できなかったことを隠しません。** 最新情報タブの先頭に、巡回時刻と失敗したソース名を必ず表示します。

## 気象庁データを使う際の法的な注意

- **出典表記が必須**です。サイトに「出典：気象庁ホームページ」を掲出しています。消さないでください
- **警報・予報の本質を変える編集は気象業務法で禁止**されています。震度やマグニチュードの表示整形は問題ありませんが、内容の書き換え・独自の予測の付加は絶対にしないでください
- `bosai/quake/data/list.json` は気象庁が公式APIとして案内しているものではありません（気象庁の内部ファイル）。予告なく形式が変わる可能性があるため、公式の `eqvol.xml` を併せて巡回しています。JSONが壊れても地震情報の取得経路が残る構成です

## 壊れたときの直し方

自治体サイトはCMS更新でHTML構造が変わります。以下は特に壊れやすい箇所です。

| 症状 | 見るところ |
|---|---|
| 宇城市の件数が0になった | `parse_uki_html()` の正規表現。属性値が引用符なしで出力されるCMS |
| 氷川町・益城町の緊急情報が0件 | `parse_kinkyu_html()`。`h2.kinkyuTitle` / `div.updDate` / `div.kinkyuNaiyo` の構造 |
| 更新の日時がおかしい | 内閣府のRSSは `pubDate` がRFC822違反（月名が `July`、TZが `+1700`）。`parse_date_loose()` で吸収している |
| 全ソースが0件 | まず `python3 crawl.py -v` で HTTP ステータスを確認。403が出たら User-Agent を疑う |
| 特定の自治体だけ消えた | `state.json` を削除して再取得。それでも駄目ならそのサイトの構造変更 |

`state.json` は消しても安全です（次回に全件取り直すだけ）。

## SNSについて

**X（旧Twitter）のAPIは使っていません。** 2026年時点で無料枠は終了し、従量課金のみです。災害時はトラフィックが跳ねるためコストが読めません。

**タイムラインの埋め込みもしていません。** X側の仕様上サーバーからのタイムライン取得ができず（データセンターIPからは429で拒否されます）、クライアント側の埋め込みは通信環境や広告ブロッカーで表示されないことがあります。災害時に見えない可能性のあるものを情報の入口にはしない、という判断です。

代わりに、**発信元の公式サイトに掲載されていることを確認したアカウントだけ**をリンク集にしています。確認できなかったものは別枠に分け、なりすましの可能性がある旨を明記しています。

氷川町・美里町・宇城市はXを運用していません（LINEのみ）。益城町は公式サイトのXリンクが切れています。小規模自治体ほどLINEが確実です。

## 運用で必ず決めておくこと

- **終了日を最初に決める。** 「〇月〇日で更新を終了し、熊本県のポータルへ引き継ぎます」をサイトに掲出しておく。閉じ方を決めていないサイトは必ず放置されます
- **1日1回はリンクを目視確認する。** 調査中、宇城市の記事URLが30分で404になるのを実際に観測しました
- **運営主体・連絡先・利用規約を公開前に整備する。** 匿名運営の災害情報サイトは信用されません
